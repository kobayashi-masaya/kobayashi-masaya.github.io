module.exports = function (req, res) {
    var name = req.query.user;
    var png1;
    var png2;
    var png3;
    
    // 【NCMB】SDKインポート
    var NCMB = require("ncmb");
    // 【NCMB】SDKの初期化
    var ncmb = new NCMB("APPLICATION_KEY", "CLIENT_KEY");
    
    // 【NCMB】各種保存先クラスの生成
    var Item = ncmb.DataStore("Item");
    var Reward1 = ncmb.DataStore("Reward1");
    var Reward2 = ncmb.DataStore("Reward2");
    var Reward3 = ncmb.DataStore("Reward3");
    
    // 【NCMB】あらかじめ準備したsuperuserユーザーでログイン
    const promise = new Promise((resolve, reject) => {
        ncmb.User.login("superuser", "super")
            .then(function (superuser) {
                /* ログイン成功時の処理 */
                // 【NCMB】Reward1クラス内のデータでnameが一致する値を全件検索する
                Reward1.equalTo("name", name)
                       .fetchAll()
                       .then(function (reward1) {
                           if(reward1[0]==="" || reward1[0]===undefined){
                               png1 = "";
                           }else{
                               // 【NCMB】Roulette_Itemクラスを全件検索する
                               Item.fetchAll()
                                   .then(function (result1) {
                                       png1 = result1[0].png[0];
                                   })
                                   .catch(function (error) {
                                       res.status(500).json({error: 500});
                                   });
                           }
                       })
                       .catch(function (error) {
                          res.status(500).send("Error: " + error);
                       });
                       
                // 以下Reward2,Reward3クラスも同様に
                Reward2.equalTo("name", name)
                       .fetchAll()
                       .then(function (reward2) {
                           if(reward2[0]==="" || reward2[0]===undefined){
                               png2 = "";
                           }else{
                               Item.fetchAll()
                                   .then(function (result2) {
                                       png2 = result2[0].png[1];
                                   })
                                   .catch(function (error) {
                                       res.status(500).json({error: 500});
                                   });
                           }
                       })
                       .catch(function (error) {
                          res.status(500).send("Error: " + error);
                       });
                
                Reward3.equalTo("name", name)
                       .fetchAll()
                       .then(function (reward3) {
                           if(reward3[0]==="" || reward3[0]===undefined){
                               png3 = "";
                               resolve();
                           }else{
                               Item.fetchAll()
                                   .then(function (result3) {
                                       png3 = result3[0].png[2];
                                       resolve();
                                   })
                                   .catch(function (error) {
                                       res.status(500).json({error: 500});
                                   });
                           }
                       })
                       .catch(function (error) {
                          res.status(500).send("Error: " + error);
                       });
            })    
            .catch(function (error) {
                res.status(500).send("Error: " + error);
            });
    });
    
    promise.then(() => setTimeout(function () {
        res.status(200).json({png1,png2,png3});
    }, 1000));
    
}