module.exports = function (req, res) {
    var NCMB = require('ncmb');
    var ncmb = new NCMB('APPLICATION_KEY', 'CLIENT_KEY');

    var Item = ncmb.DataStore('Roulette_Item');
    var Reward1 = ncmb.DataStore('Reward1');
    var Reward2 = ncmb.DataStore('Reward2');
    var Reward3 = ncmb.DataStore('Reward3');
    var name = req.query.user;
    var png1;
    var png2;
    var png3;
    var user_login = new ncmb.User({userName: "superuser",password: "super"});
    // ログイン後処理
    const promise = new Promise((resolve, reject) => {
        ncmb.User.login(user_login)
            .then(function (data) {
                Reward1.equalTo("name", name)
                    .fetchAll()
                    .then(function (reward1) {
                        if(reward1[0]==="" || reward1[0]===undefined){
                            png1 = "";
                        }
                        else{
                            Item.fetchAll()
                                .then(function (result1) {
                                    png1 = result1[0].png[0];
                                })
                                .catch(function (error) {
                                    res.status(500).json({error: 500});//500
                                })                        
                        }     
                    })
                    .catch(function (error) {
                       res.status(500).send("Error: " + error);
                    })     

                Reward2.equalTo("name", name)
                    .fetchAll()
                    .then(function (reward2) {
                      if(reward2[0]==="" || reward2[0]===undefined){
                        png2 = "";
                      }
                      else{
                          Item.fetchAll()
                              .then(function (result2) {
                                  png2 = result2[0].png[1];
                              })
                              .catch(function (error) {
                                  res.status(500).json({error: 500});//500
                              })                        
                      }        
                    })
                    .catch(function (error) {
                        res.status(500).send("Error: " + error);
                    })     

                Reward3.equalTo("name", name)
                    .fetchAll()
                    .then(function (reward3) {
                      if(reward3[0]==="" || reward3[0]===undefined){
                          png3 = "";
                          resolve()
                      }
                      else{
                          Item.fetchAll()
                              .then(function (result3) {
                                  png3 = result3[0].png[2];
                                  resolve()
                              })
                              .catch(function (error) {
                                  res.status(500).json({error: 500});//500
                              })                        
                      }    
                    })  
                    .catch(function (error) {
                       res.status(500).send("Error: " + error);
                    })     
            })    
            .catch(function (error) {
                res.status(500).send("Error: " + error);
            });
    });
    promise.then(() => setTimeout(function () {
        res.status(200).json({png1,png2,png3});
    }, 1000));
}