module.exports = function (req, res) {
    var NCMB = require('ncmb');
    var ncmb = new NCMB('APPLICATION_KEY', 'CLIENT_KEY');    
    var name = String(req.query.user);
    var stopNumber = req.query.stopNumber;
    var StoreName = 'Reward' + String(stopNumber);
    var Reward = ncmb.DataStore(StoreName);
    var user_login = new ncmb.User({userName: "superuser",password: "super"});

    ncmb.User.login(user_login)
        .then(function (data) {
            Reward.equalTo('name', name)
                .fetchAll()
                .then(function(results) {
                    if(results[0]==="" || results[0]===undefined){
                        var nameAdd = new Reward();
                        nameAdd.set("name", name)
                            .save() 
                            .then(function (nameAdd) {
                                nameAdd.set("name", name);
                                return nameAdd.update();
                            })
                            .then(function (success) {
                                res.send("POST data successfully!");   
                            })
                            .catch(function (error) {
                                res.status(500).send("Error: " + error);
                            });
                    }
                    else{
                        res.send("POST data already");
                    }      
                })
                .catch(function (error) {
                    res.status(500).send("Error: " + error);
                });       
        })
        .catch(function (err) {
            res.status(500).send("Error: " + error);
        });
}