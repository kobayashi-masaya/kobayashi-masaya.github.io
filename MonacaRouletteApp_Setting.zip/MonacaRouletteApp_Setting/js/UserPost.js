module.exports = function (req, res) {
    var name = String(req.query.user);
    var stopNumber = req.query.stopNumber;
    var className = "Reward" + String(stopNumber);
    
    // 【NCMB】SDKインポート
    var NCMB = require("ncmb");
    // 【NCMB】SDKの初期化
    var ncmb = new NCMB("APPLICATION_KEY", "CLIENT_KEY");
    // 【NCMB】あらかじめ準備したsuperuserユーザーでログイン
    ncmb.User.login("superuser", "super")
        .then(function (superuser) {
            /* ログイン成功時の処理 */
            // 【NCMB】ルーレットの結果毎にユーザー名を保存する
            // 保存先クラスの生成
            var Reward = ncmb.DataStore(className);
            // 致する情報を取得する
            Reward.equalTo("name", name)
                  .fetchAll()
                  .then(function(results) {
                      /* 取得成功時の処理 */
                      var objectId = "";
                      if (results[0]==="" || results[0]===undefined) {
                          objectId = "";
                      }else{
                          objectId = results[0].objectId;
                      }
                      // 新規登録または更新をする
                      var reward = new Reward();
                      reward.set("name", name);
                      (objectId == "" ? reward.save() : reward.set("objectId", objectId).update())
                          .then(function (success) {
                              /* 保存または更新成功時の処理 */
                              res.send("POST data successfully!");
                          })
                          .catch(function (error) {
                              /* 保存または更新失敗時の処理 */
                              res.status(500).send("Error: " + error);
                          });
                  })
                  .catch(function (error) {
                      /* 取得失敗時の処理 */
                      res.status(500).send("Error: " + error);
                  });
        })
        .catch(function (err) {
            /* ログイン失敗時の処理 */
            res.status(500).send("Error: " + error);
        });
}