module.exports = function (req, res) {
    var NCMB = require('ncmb');
    var ncmb = new NCMB('APPLICATION_KEY', 'CLIENT_KEY');    //objectIdがgachaIdに一致するものを検索して取得（ヒットするものは１つ）
    var Item = ncmb.DataStore('Roulette_Item');
    var name = req.query.user;
    var pass = req.query.pass;
    Item.fetchAll().then(function (results) {
        // ランダムに 1 件選択
        item = results[Math.floor(Math.random() * results.length)];
        var rewardNum = selectReward(results[0].probability);
        if (rewardNum == -1) {
            res.status(500).json({
                "message": "Probabilities of rewards must be defined as Array(length=2)"
            });
        }
        var stopNumber = results[0].rewards[rewardNum];
        var png = results[0].png[rewardNum];
        res.status(200).json({stopNumber,png});
    })
    .catch(function (error) {
        res.status(500).send("Error: " + error);
    });
}

function selectReward(probabilities) {
  // probabilities は Array か
  if (!(Array.isArray(probabilities))) return -1;
  // probabilities の要素数は２か
  if (probabilities.length != 2) return -1;
  const p0 = Number(probabilities[0]); // rewards[0]が選択される確率
  const p1 = Number(probabilities[1]); // rewards[1]が   〃
  // 今回はp0(1等)が20%,p1(2等)が30%,残り(3等)が50%で当たりを出している
  var randNum = Math.random();
  if (randNum <= p0) return 0;
  else if (randNum <= p0 + p1) return 1;
  else return 2;
}