module.exports = function (req, res) {
    // 【NCMB】SDKインポート
    var NCMB = require("ncmb");
    
    // 【NCMB】SDKの初期化
    var ncmb = new NCMB("APPLICATION_KEY", "CLIENT_KEY"); 
    
    /* 【NCMB】データストアから確率を取得する */
    // 保存先クラスの指定
    var Item = ncmb.DataStore("Item");
    // 全件取得
    Item.fetchAll()
        .then(function (results) {
            /* 取得成功時の処理 */
            // 確率によりクーポンを決定
            var rewardNum = selectReward(results[0].rate);
            // データに不備があった場合の処理
            if (rewardNum == -1) {
                res.status(500).json({
                    "message": "Probabilities of rewards must be defined as Array(length=2)"
                });
            }
            // クーポン番号と画像情報を返却
            var stopNumber = results[0].rewards[rewardNum];
            var png = results[0].png[rewardNum];
            res.status(200).json({stopNumber,png});
        })
        .catch(function (error) {
            /* 取得失敗時の処理 */
            res.status(500).send("Error: " + error);
        });
}

// クーポンの決定処理
function selectReward(probabilities) {
    // probabilitiesが配列かどうか確認
    if (!(Array.isArray(probabilities))) return -1;
    
    // probabilities の要素数の確認
    if (probabilities.length != 2) return -1;
    
    const p0 = Number(probabilities[0]); // rewards[0]が選択される確率
    const p1 = Number(probabilities[1]); // rewards[1]が選択される確率
    
    // 乱数の生成
    var randNum = Math.random();
    // クーポンの決定
    if (randNum <= p0) return 0;
    else if (randNum <= p0 + p1) return 1;
    else return 2;
}